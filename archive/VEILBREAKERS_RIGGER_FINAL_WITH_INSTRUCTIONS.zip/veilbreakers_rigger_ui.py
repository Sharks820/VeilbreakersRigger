#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                    VEILBREAKERS RIGGER - PROFESSIONAL UI                             ║
║                                                                                      ║
║  A beautiful, intuitive interface for the ultimate monster rigging system            ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
"""

import gradio as gr
import numpy as np
from PIL import Image, ImageDraw
from pathlib import Path
import json
import tempfile
import shutil
import os
from typing import Optional, List, Tuple, Dict, Any

# Import our rigger
from veilbreakers_rigger import (
    VeilbreakersRigger, 
    BODY_TEMPLATES, 
    InpaintQuality,
    ExportFormat,
    BodyPart,
    Point
)

# =============================================================================
# GLOBAL STATE
# =============================================================================

class AppState:
    """Application state manager"""
    
    def __init__(self):
        self.rigger: Optional[VeilbreakersRigger] = None
        self.mode = "select"  # "select", "add", "subtract"
        self.current_part_name = ""
        self.history: List[np.ndarray] = []
        self.history_index = -1
        
    def init_rigger(self, sam_size: str = "large"):
        """Initialize or reinitialize the rigger"""
        try:
            self.rigger = VeilbreakersRigger(
                output_dir="./output",
                sam_size=sam_size,
                use_fallback=True
            )
            return True
        except Exception as e:
            print(f"Error initializing rigger: {e}")
            self.rigger = VeilbreakersRigger(
                output_dir="./output",
                sam_size="tiny",
                use_fallback=True
            )
            return False
    
    def save_state(self):
        """Save current state to history"""
        if self.rigger and self.rigger.current_rig:
            self.history = self.history[:self.history_index + 1]
            self.history.append(self.rigger.get_working_image().copy())
            self.history_index = len(self.history) - 1
            # Limit history size
            if len(self.history) > 20:
                self.history = self.history[-20:]
                self.history_index = len(self.history) - 1
    
    def undo(self) -> Optional[np.ndarray]:
        """Undo to previous state"""
        if self.history_index > 0:
            self.history_index -= 1
            return self.history[self.history_index]
        return None
    
    def redo(self) -> Optional[np.ndarray]:
        """Redo to next state"""
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            return self.history[self.history_index]
        return None
    
    def reset(self):
        """Reset all state"""
        if self.rigger:
            self.rigger.reset()
        self.mode = "select"
        self.current_part_name = ""
        self.history = []
        self.history_index = -1

STATE = AppState()

# =============================================================================
# UI HELPER FUNCTIONS
# =============================================================================

def create_visualization(show_mask: bool = True, alpha: float = 0.4) -> Optional[np.ndarray]:
    """Create visualization of current state"""
    if STATE.rigger is None or STATE.rigger.current_rig is None:
        return None
    
    try:
        return STATE.rigger.get_visualization(
            show_masks=show_mask,
            show_points=True,
            show_pivots=True,
            alpha=alpha
        )
    except:
        return STATE.rigger.get_working_image()

def get_parts_table() -> List[List[Any]]:
    """Get parts as table data"""
    if STATE.rigger is None:
        return []
    
    parts = STATE.rigger.get_parts()
    return [[p.name, p.z_index, p.parent, f"{p.confidence:.0%}" if p.confidence else "manual"] 
            for p in sorted(parts, key=lambda x: x.z_index)]

def get_part_choices() -> List[str]:
    """Get list of part names for dropdowns"""
    if STATE.rigger is None:
        return [""]
    return [""] + [p.name for p in STATE.rigger.get_parts()]

# =============================================================================
# MAIN UI FUNCTIONS
# =============================================================================

def load_image(image, sam_size: str):
    """Load an image into the rigger"""
    if image is None:
        return None, "❌ No image provided", [], gr.update(choices=[""]), None
    
    # Initialize rigger if needed
    if STATE.rigger is None:
        STATE.init_rigger(sam_size)
    
    STATE.reset()
    
    # Load image
    try:
        if isinstance(image, str):
            STATE.rigger.load_image(image)
        else:
            STATE.rigger.load_image_array(image, "monster")
        
        STATE.save_state()
        
        vis = create_visualization(show_mask=False)
        parts = get_parts_table()
        choices = get_part_choices()
        
        return (
            vis,
            f"✅ Loaded image ({STATE.rigger.current_rig.original_image.shape[1]}x{STATE.rigger.current_rig.original_image.shape[0]})",
            parts,
            gr.update(choices=choices),
            STATE.rigger.get_original_image()
        )
    except Exception as e:
        return None, f"❌ Error: {str(e)}", [], gr.update(choices=[""]), None


def on_image_click(image, evt: gr.SelectData, mode: str):
    """Handle click on image"""
    if STATE.rigger is None or STATE.rigger.current_rig is None:
        return None, "Load an image first!"
    
    x, y = evt.index
    
    try:
        if mode == "select" or STATE.rigger.current_mask is None:
            # New selection
            STATE.rigger.click_segment(x, y)
            status = f"🎯 Selected at ({x}, {y}) - Click 'Add Part' or refine with +/- buttons"
        elif mode == "add":
            # Add to selection
            STATE.rigger.refine_add(x, y)
            status = f"➕ Added point at ({x}, {y})"
        elif mode == "subtract":
            # Remove from selection
            STATE.rigger.refine_subtract(x, y)
            status = f"➖ Removed point at ({x}, {y})"
        else:
            STATE.rigger.click_segment(x, y)
            status = f"🎯 Selected at ({x}, {y})"
        
        vis = create_visualization()
        return vis, status
        
    except Exception as e:
        return image, f"❌ Error: {str(e)}"


def auto_detect(prompt: str, box_thresh: float, text_thresh: float, quality: str):
    """Auto-detect parts from text prompt"""
    if STATE.rigger is None or STATE.rigger.current_rig is None:
        return None, "Load an image first!", [], gr.update(choices=[""])
    
    if not prompt:
        return None, "Enter a detection prompt!", [], gr.update(choices=[""])
    
    quality_map = {
        "Fast (OpenCV)": InpaintQuality.FAST,
        "Standard (LaMa)": InpaintQuality.STANDARD,
        "High (LaMa x2)": InpaintQuality.HIGH,
        "Ultra (Stable Diffusion)": InpaintQuality.ULTRA
    }
    
    try:
        parts = STATE.rigger.auto_detect(
            prompt,
            box_threshold=box_thresh,
            text_threshold=text_thresh,
            inpaint_quality=quality_map.get(quality, InpaintQuality.STANDARD)
        )
        
        STATE.save_state()
        
        if not parts:
            return (
                create_visualization(show_mask=False),
                "⚠️ No parts detected. Try lowering thresholds or changing prompt.",
                get_parts_table(),
                gr.update(choices=get_part_choices())
            )
        
        return (
            create_visualization(show_mask=False),
            f"✅ Detected {len(parts)} parts: {', '.join(p.name for p in parts)}",
            get_parts_table(),
            gr.update(choices=get_part_choices())
        )
        
    except Exception as e:
        return None, f"❌ Error: {str(e)}", [], gr.update(choices=[""])


def apply_preset(preset_name: str, quality: str):
    """Apply a body template preset"""
    if STATE.rigger is None or STATE.rigger.current_rig is None:
        return None, "Load an image first!", [], gr.update(choices=[""])
    
    if preset_name not in BODY_TEMPLATES or preset_name == "custom":
        return None, "Select a valid preset", [], gr.update(choices=[""])
    
    quality_map = {
        "Fast (OpenCV)": InpaintQuality.FAST,
        "Standard (LaMa)": InpaintQuality.STANDARD,
        "High (LaMa x2)": InpaintQuality.HIGH,
        "Ultra (Stable Diffusion)": InpaintQuality.ULTRA
    }
    
    try:
        parts = STATE.rigger.auto_detect_preset(
            preset_name,
            inpaint_quality=quality_map.get(quality, InpaintQuality.STANDARD)
        )
        
        STATE.save_state()
        
        if not parts:
            return (
                create_visualization(show_mask=False),
                "⚠️ No parts detected with this preset.",
                get_parts_table(),
                gr.update(choices=get_part_choices())
            )
        
        return (
            create_visualization(show_mask=False),
            f"✅ Applied '{preset_name}' preset - {len(parts)} parts detected",
            get_parts_table(),
            gr.update(choices=get_part_choices())
        )
        
    except Exception as e:
        return None, f"❌ Error: {str(e)}", [], gr.update(choices=[""])


def add_part(name: str, z_index: int, parent: str, pivot_type: str, quality: str):
    """Add current selection as a part"""
    if STATE.rigger is None:
        return None, "Load an image first!", [], gr.update(choices=[""])
    
    if STATE.rigger.current_mask is None:
        return None, "No selection! Click on the image first.", [], gr.update(choices=[""])
    
    if not name:
        # Generate name
        existing = [p.name for p in STATE.rigger.get_parts()]
        counter = len(existing) + 1
        name = f"part_{counter}"
    
    quality_map = {
        "Fast (OpenCV)": InpaintQuality.FAST,
        "Standard (LaMa)": InpaintQuality.STANDARD,
        "High (LaMa x2)": InpaintQuality.HIGH,
        "Ultra (Stable Diffusion)": InpaintQuality.ULTRA
    }
    
    try:
        part = STATE.rigger.confirm_selection(
            name=name,
            z_index=int(z_index),
            parent=parent if parent else "",
            pivot_type=pivot_type.lower().replace(" ", "_"),
            inpaint_quality=quality_map.get(quality, InpaintQuality.STANDARD)
        )
        
        STATE.save_state()
        
        return (
            create_visualization(show_mask=False),
            f"✅ Added part: {name}",
            get_parts_table(),
            gr.update(choices=get_part_choices())
        )
        
    except Exception as e:
        return None, f"❌ Error: {str(e)}", [], gr.update(choices=[""])


def clear_selection():
    """Clear current selection"""
    if STATE.rigger:
        STATE.rigger._clear_selection()
    
    return (
        create_visualization(show_mask=False) if STATE.rigger else None,
        "Selection cleared"
    )


def remove_part(name: str):
    """Remove a part"""
    if STATE.rigger is None or not name:
        return None, "Select a part to remove", [], gr.update(choices=[""])
    
    try:
        STATE.rigger.remove_part(name)
        STATE.save_state()
        
        return (
            create_visualization(show_mask=False),
            f"Removed: {name}",
            get_parts_table(),
            gr.update(choices=get_part_choices())
        )
    except Exception as e:
        return None, f"❌ Error: {str(e)}", [], gr.update(choices=[""])


def update_part(name: str, z_index: int, parent: str, pivot: str):
    """Update part properties"""
    if STATE.rigger is None or not name:
        return None, "Select a part to update", []
    
    try:
        STATE.rigger.set_part_z_index(name, int(z_index))
        STATE.rigger.set_part_parent(name, parent if parent else "")
        STATE.rigger.set_part_pivot(name, pivot.lower().replace(" ", "_"))
        
        return (
            create_visualization(show_mask=False),
            f"Updated: {name}",
            get_parts_table()
        )
    except Exception as e:
        return None, f"❌ Error: {str(e)}", []


def preview_part(name: str):
    """Preview a specific part"""
    if STATE.rigger is None or not name:
        return None
    
    part = STATE.rigger.get_part(name)
    if part and part.image is not None:
        return part.image
    return None


def export_rig(monster_name: str, export_format: str):
    """Export the rig"""
    if STATE.rigger is None or STATE.rigger.current_rig is None:
        return "Load an image first!", None
    
    if not STATE.rigger.get_parts():
        return "No parts to export! Add some parts first.", None
    
    format_map = {
        "Godot 4.x (2D)": ExportFormat.GODOT_4,
        "Godot 4.x (3D Billboards)": ExportFormat.GODOT_4_3D,
        "Godot 3.x": ExportFormat.GODOT_3,
        "Spine JSON": ExportFormat.SPINE,
        "PNGs Only": ExportFormat.PNG_SEQUENCE,
    }
    
    try:
        output_path = STATE.rigger.export(
            name=monster_name if monster_name else None,
            format=format_map.get(export_format, ExportFormat.GODOT_4)
        )
        
        # Create zip for download
        output_dir = Path(output_path).parent
        zip_name = output_dir.name
        zip_path = f"/tmp/{zip_name}_rig.zip"
        
        shutil.make_archive(zip_path.replace('.zip', ''), 'zip', output_dir)
        
        format_info = {
            "Godot 4.x (2D)": "2D scene with Sprite2D nodes",
            "Godot 4.x (3D Billboards)": "3D scene with billboarded Sprite3D nodes",
            "Godot 3.x": "Godot 3.x compatible 2D scene",
            "Spine JSON": "Spine skeleton format",
            "PNGs Only": "PNG images with metadata",
        }
        
        return f"✅ Exported: {format_info.get(export_format, '')} → {output_path}", zip_path
        
    except Exception as e:
        return f"❌ Error: {str(e)}", None


def reset_all():
    """Reset everything"""
    STATE.reset()
    return None, "Reset complete", [], gr.update(choices=[""]), None


def undo_action():
    """Undo last action"""
    img = STATE.undo()
    if img is not None and STATE.rigger:
        STATE.rigger.current_rig.working_image = img
        STATE.rigger.segmenter.set_image(img)
        return img, "Undo successful"
    return None, "Nothing to undo"


def redo_action():
    """Redo last undone action"""
    img = STATE.redo()
    if img is not None and STATE.rigger:
        STATE.rigger.current_rig.working_image = img
        STATE.rigger.segmenter.set_image(img)
        return img, "Redo successful"
    return None, "Nothing to redo"


def get_preset_info(preset_name: str) -> str:
    """Get info about a preset"""
    if preset_name not in BODY_TEMPLATES:
        return ""
    
    template = BODY_TEMPLATES[preset_name]
    info = f"**{template['name']}**\n\n"
    
    if template['prompt']:
        parts = template['prompt'].split(' . ')
        info += f"**Parts ({len(parts)}):**\n"
        for i, part in enumerate(parts):
            z = template['z_order'].index(part) if part in template['z_order'] else i
            info += f"- {part} (z={z})\n"
    else:
        info += "Custom preset - define your own parts"
    
    return info


# =============================================================================
# BUILD THE UI
# =============================================================================

def create_ui():
    """Create the Gradio interface"""
    
    # Custom CSS for professional look
    css = """
    .container { max-width: 1400px; margin: auto; }
    .title { text-align: center; margin-bottom: 1rem; }
    .status-box { padding: 10px; border-radius: 8px; margin: 5px 0; }
    .part-table { max-height: 300px; overflow-y: auto; }
    footer { display: none !important; }
    """
    
    with gr.Blocks(
        title="VEILBREAKERS Monster Rigger",
        theme=gr.themes.Soft(
            primary_hue="orange",
            secondary_hue="slate",
        ),
        css=css
    ) as app:
        
        # Header
        gr.Markdown("""
        # 🔥 VEILBREAKERS Monster Rigger
        ### The Ultimate Cutout Animation System
        
        Transform your monster art into fully-rigged, animated characters with AI-powered segmentation.
        """)
        
        with gr.Row():
            # ═══════════════════════════════════════════════════════════════
            # LEFT PANEL - Image and Controls
            # ═══════════════════════════════════════════════════════════════
            with gr.Column(scale=2):
                
                with gr.Tab("🖼️ Workspace"):
                    # Main image display
                    main_image = gr.Image(
                        label="Monster Image",
                        type="numpy",
                        height=550,
                        interactive=True
                    )
                    
                    with gr.Row():
                        load_btn = gr.Button("📂 Load Image", variant="primary", size="sm")
                        clear_btn = gr.Button("🗑️ Clear Selection", size="sm")
                        reset_btn = gr.Button("🔄 Reset All", variant="stop", size="sm")
                    
                    with gr.Row():
                        undo_btn = gr.Button("↩️ Undo", size="sm")
                        redo_btn = gr.Button("↪️ Redo", size="sm")
                    
                    # Status
                    status_text = gr.Textbox(
                        label="Status",
                        interactive=False,
                        lines=2
                    )
                
                with gr.Tab("🎯 Selection Mode"):
                    gr.Markdown("""
                    ### Click Mode
                    - **Select**: Start a new selection
                    - **Add (+)**: Add to current selection  
                    - **Subtract (-)**: Remove from current selection
                    """)
                    
                    mode_radio = gr.Radio(
                        choices=["select", "add", "subtract"],
                        value="select",
                        label="Click Mode",
                        interactive=True
                    )
                
                with gr.Tab("⚙️ Settings"):
                    sam_size = gr.Dropdown(
                        choices=["tiny", "small", "base", "large"],
                        value="large",
                        label="SAM Model Size",
                        info="Larger = more accurate, slower"
                    )
                    
                    inpaint_quality = gr.Dropdown(
                        choices=["Fast (OpenCV)", "Standard (LaMa)", "High (LaMa x2)", "Ultra (Stable Diffusion)"],
                        value="Standard (LaMa)",
                        label="Inpainting Quality"
                    )
            
            # ═══════════════════════════════════════════════════════════════
            # RIGHT PANEL - Part Controls
            # ═══════════════════════════════════════════════════════════════
            with gr.Column(scale=1):
                
                with gr.Tab("🤖 Auto-Detect"):
                    gr.Markdown("### AI-Powered Detection")
                    
                    preset_dropdown = gr.Dropdown(
                        choices=list(BODY_TEMPLATES.keys()),
                        value="quadruped",
                        label="Body Template"
                    )
                    
                    preset_info = gr.Markdown()
                    
                    apply_preset_btn = gr.Button("🚀 Apply Preset", variant="primary")
                    
                    gr.Markdown("---")
                    gr.Markdown("### Custom Prompt")
                    
                    custom_prompt = gr.Textbox(
                        label="Detection Prompt",
                        placeholder="head . body . arms . legs . tail",
                        info="Separate parts with ' . '"
                    )
                    
                    with gr.Row():
                        box_thresh = gr.Slider(0.1, 0.9, value=0.25, step=0.05, label="Box Threshold")
                        text_thresh = gr.Slider(0.1, 0.9, value=0.25, step=0.05, label="Text Threshold")
                    
                    detect_btn = gr.Button("🔍 Detect Parts", variant="primary")
                
                with gr.Tab("✋ Manual Add"):
                    gr.Markdown("### Add Selection as Part")
                    gr.Markdown("Click on the image to select, then fill in details below.")
                    
                    part_name = gr.Textbox(
                        label="Part Name",
                        placeholder="e.g., head, arm_left, tail"
                    )
                    
                    z_index = gr.Slider(
                        0, 20, value=0, step=1,
                        label="Z-Index (Layer Order)",
                        info="Higher = in front"
                    )
                    
                    parent_dropdown = gr.Dropdown(
                        choices=[""],
                        value="",
                        label="Parent Part",
                        allow_custom_value=True
                    )
                    
                    pivot_type = gr.Dropdown(
                        choices=["Center", "Top Center", "Bottom Center", 
                                 "Left Center", "Right Center",
                                 "Top Left", "Top Right", 
                                 "Bottom Left", "Bottom Right"],
                        value="Center",
                        label="Pivot Point"
                    )
                    
                    add_part_btn = gr.Button("✅ Add Part", variant="primary", size="lg")
                
                with gr.Tab("📋 Parts List"):
                    parts_table = gr.Dataframe(
                        headers=["Name", "Z-Index", "Parent", "Confidence"],
                        label="Extracted Parts",
                        interactive=False,
                        wrap=True
                    )
                    
                    gr.Markdown("### Edit Part")
                    
                    edit_part_dropdown = gr.Dropdown(
                        choices=[""],
                        label="Select Part"
                    )
                    
                    with gr.Row():
                        edit_z = gr.Number(value=0, label="Z-Index", precision=0)
                        edit_parent = gr.Dropdown(choices=[""], label="Parent")
                    
                    edit_pivot = gr.Dropdown(
                        choices=["Center", "Top Center", "Bottom Center", 
                                 "Left Center", "Right Center"],
                        value="Center",
                        label="Pivot"
                    )
                    
                    with gr.Row():
                        update_btn = gr.Button("💾 Update", size="sm")
                        remove_btn = gr.Button("🗑️ Remove", variant="stop", size="sm")
                    
                    gr.Markdown("### Preview")
                    part_preview = gr.Image(label="Part Preview", height=150)
        
        gr.Markdown("---")
        
        # ═══════════════════════════════════════════════════════════════════
        # EXPORT SECTION
        # ═══════════════════════════════════════════════════════════════════
        with gr.Row():
            with gr.Column(scale=2):
                gr.Markdown("### 💾 Export")
                
                with gr.Row():
                    monster_name = gr.Textbox(
                        label="Monster Name",
                        placeholder="shadow_wolf",
                        scale=2
                    )
                    export_format = gr.Dropdown(
                        choices=["Godot 4.x (2D)", "Godot 4.x (3D Billboards)", "Godot 3.x", "Spine JSON", "PNGs Only"],
                        value="Godot 4.x (2D)",
                        label="Format",
                        scale=1
                    )
                    export_btn = gr.Button("🚀 Export Rig", variant="primary", scale=1, size="lg")
            
            with gr.Column(scale=1):
                export_status = gr.Textbox(label="Export Status", interactive=False)
                download_file = gr.File(label="Download")
        
        # Hidden state for original image
        original_image = gr.State(None)
        
        # ═══════════════════════════════════════════════════════════════════
        # EVENT HANDLERS
        # ═══════════════════════════════════════════════════════════════════
        
        # Load image
        load_btn.click(
            fn=load_image,
            inputs=[main_image, sam_size],
            outputs=[main_image, status_text, parts_table, parent_dropdown, original_image]
        )
        
        # Image click
        main_image.select(
            fn=on_image_click,
            inputs=[main_image, mode_radio],
            outputs=[main_image, status_text]
        )
        
        # Clear selection
        clear_btn.click(
            fn=clear_selection,
            outputs=[main_image, status_text]
        )
        
        # Reset all
        reset_btn.click(
            fn=reset_all,
            outputs=[main_image, status_text, parts_table, parent_dropdown, original_image]
        )
        
        # Undo/Redo
        undo_btn.click(fn=undo_action, outputs=[main_image, status_text])
        redo_btn.click(fn=redo_action, outputs=[main_image, status_text])
        
        # Preset info
        preset_dropdown.change(
            fn=get_preset_info,
            inputs=[preset_dropdown],
            outputs=[preset_info]
        )
        
        # Apply preset
        apply_preset_btn.click(
            fn=apply_preset,
            inputs=[preset_dropdown, inpaint_quality],
            outputs=[main_image, status_text, parts_table, parent_dropdown]
        )
        
        # Custom detection
        detect_btn.click(
            fn=auto_detect,
            inputs=[custom_prompt, box_thresh, text_thresh, inpaint_quality],
            outputs=[main_image, status_text, parts_table, parent_dropdown]
        )
        
        # Add part
        add_part_btn.click(
            fn=add_part,
            inputs=[part_name, z_index, parent_dropdown, pivot_type, inpaint_quality],
            outputs=[main_image, status_text, parts_table, parent_dropdown]
        )
        
        # Edit part dropdown updates
        def update_edit_fields(name):
            if STATE.rigger is None or not name:
                return 0, "", "Center", None
            
            part = STATE.rigger.get_part(name)
            if part:
                return part.z_index, part.parent, "Center", part.image
            return 0, "", "Center", None
        
        edit_part_dropdown.change(
            fn=update_edit_fields,
            inputs=[edit_part_dropdown],
            outputs=[edit_z, edit_parent, edit_pivot, part_preview]
        )
        
        # Update part
        update_btn.click(
            fn=update_part,
            inputs=[edit_part_dropdown, edit_z, edit_parent, edit_pivot],
            outputs=[main_image, status_text, parts_table]
        )
        
        # Remove part
        remove_btn.click(
            fn=remove_part,
            inputs=[edit_part_dropdown],
            outputs=[main_image, status_text, parts_table, parent_dropdown]
        )
        
        # Keep edit dropdown synced
        parts_table.change(
            fn=lambda: gr.update(choices=get_part_choices()),
            outputs=[edit_part_dropdown]
        )
        
        # Export
        export_btn.click(
            fn=export_rig,
            inputs=[monster_name, export_format],
            outputs=[export_status, download_file]
        )
        
        # Initial preset info
        app.load(
            fn=lambda: get_preset_info("quadruped"),
            outputs=[preset_info]
        )
    
    return app


def launch_ui():
    """Launch the UI"""
    print("""
    ╔══════════════════════════════════════════════════════════════════════════════╗
    ║                    VEILBREAKERS MONSTER RIGGER                               ║
    ║                         Launching UI...                                      ║
    ╚══════════════════════════════════════════════════════════════════════════════╝
    """)
    
    # Initialize state
    STATE.init_rigger()
    
    # Create and launch
    app = create_ui()
    app.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_error=True,
        favicon_path=None
    )


if __name__ == "__main__":
    launch_ui()
