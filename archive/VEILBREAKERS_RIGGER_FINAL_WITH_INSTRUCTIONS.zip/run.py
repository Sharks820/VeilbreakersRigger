#!/usr/bin/env python3
"""
VEILBREAKERS Monster Rigger - Quick Launcher
"""

import sys

def check_basic_deps():
    """Check if basic dependencies are available"""
    missing = []
    
    try:
        import numpy
    except ImportError:
        missing.append("numpy")
    
    try:
        import PIL
    except ImportError:
        missing.append("Pillow")
    
    try:
        import gradio
    except ImportError:
        missing.append("gradio")
    
    try:
        import cv2
    except ImportError:
        missing.append("opencv-python")
    
    if missing:
        print("❌ Missing dependencies:")
        for dep in missing:
            print(f"   - {dep}")
        print(f"\nInstall with: pip install {' '.join(missing)}")
        return False
    
    return True

def check_ai_deps():
    """Check AI dependencies"""
    has_sam = False
    has_gd = False
    has_lama = False
    
    try:
        import sam2
        has_sam = True
    except ImportError:
        pass
    
    try:
        import groundingdino
        has_gd = True
    except ImportError:
        pass
    
    try:
        from simple_lama_inpainting import SimpleLama
        has_lama = True
    except ImportError:
        pass
    
    return has_sam, has_gd, has_lama

def main():
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║     ██╗   ██╗███████╗██╗██╗     ██████╗ ██████╗ ███████╗ █████╗ ██╗  ██╗    ║
║     ██║   ██║██╔════╝██║██║     ██╔══██╗██╔══██╗██╔════╝██╔══██╗██║ ██╔╝    ║
║     ██║   ██║█████╗  ██║██║     ██████╔╝██████╔╝█████╗  ███████║█████╔╝     ║
║     ╚██╗ ██╔╝██╔══╝  ██║██║     ██╔══██╗██╔══██╗██╔══╝  ██╔══██║██╔═██╗     ║
║      ╚████╔╝ ███████╗██║███████╗██████╔╝██║  ██║███████╗██║  ██║██║  ██╗    ║
║       ╚═══╝  ╚══════╝╚═╝╚══════╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝    ║
║                                                                              ║
║                         MONSTER RIGGER v2.0                                  ║
║                  The Ultimate Cutout Animation System                        ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)
    
    # Check dependencies
    if not check_basic_deps():
        sys.exit(1)
    
    has_sam, has_gd, has_lama = check_ai_deps()
    
    print("AI Features Status:")
    print(f"  {'✅' if has_sam else '❌'} SAM 2 (AI Segmentation)")
    print(f"  {'✅' if has_gd else '❌'} Grounding DINO (Auto-Detection)")
    print(f"  {'✅' if has_lama else '❌'} LaMa (AI Inpainting)")
    
    if not has_sam:
        print("\n⚠️  SAM 2 not found - using OpenCV fallback (less accurate)")
        print("   For best results, install SAM 2:")
        print("   git clone https://github.com/facebookresearch/sam2")
        print("   cd sam2 && pip install -e .")
    
    if not has_gd:
        print("\n⚠️  Grounding DINO not found - auto-detection disabled")
        print("   You can still use manual click-to-segment")
    
    if not has_lama:
        print("\n⚠️  LaMa not found - using OpenCV inpainting (lower quality)")
        print("   pip install simple-lama-inpainting")
    
    print("\n" + "═" * 78)
    print("Launching UI... Open http://localhost:7860 in your browser")
    print("═" * 78 + "\n")
    
    # Launch
    from veilbreakers_rigger_ui import launch_ui
    launch_ui()

if __name__ == "__main__":
    main()
